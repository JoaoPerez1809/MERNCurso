import reactLogo from '../../assets/react.svg'
import viteLogo from '/vite.svg'
import './styles.css'

function Title({ name, paragrafo }) {
  // const name = "João Perez";
  let cargo = "dev";
  return (
    <>
      <div>
        <a href="https://vitejs.dev" target="_blank">
          <img src={viteLogo} className="logo" alt="Vite logo" />
        </a>
        <a href="https://react.dev" target="_blank">
          <img src={reactLogo} className="logo react" alt="React logo" />
        </a>
      </div>
      <h1>{`${name} é um ${cargo} `}</h1>
      {paragrafo ? (
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci consectetur unde incidunt corrupti magni! Maiores molestiae repudiandae modi repellat nam atque distinctio error molestias soluta dicta. Dignissimos voluptate autem sequi!</p>
        ) : (<p>Não tem paragrafo</p>)
      }
    </>
  )
}

export default Title;
