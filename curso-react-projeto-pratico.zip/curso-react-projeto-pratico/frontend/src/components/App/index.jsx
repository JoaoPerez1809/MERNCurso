import React from "react";
import ReactDOM from "react-dom/client";
import TodoList from "../ToDoList";

function App() {
  return (
    <React.StrictMode>
      <TodoList />
    </React.StrictMode>
  );
}


const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);

export default App;
