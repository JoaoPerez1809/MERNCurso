import Item from "../models/item.model.js";

export const createItem = async (req, res) => {
    try {
    const { text } = req.body;
    const newItem = new Item({ text});
    const savedItem = await newItem.save();
    res.status(201).json(savedItem);      
    } catch (error) {
        res.status(500).json({ message: error.message});
    }
};